
Movimiento: WASD & RIGHT, LEFT, UP, DOWN

Ataque a distancia: "Espacio" 

Ataque melee: "E" (ya tiene el pvto parry)

Sprint: "Shift"

Menu interactivo: "esc"

interactuar: "T" (solo se puede interactuar con la caja por ahora)