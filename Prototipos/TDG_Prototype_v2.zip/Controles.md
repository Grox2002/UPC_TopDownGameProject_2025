
Movimiento: WASD & RIGHT, LEFT, UP, DOWN

Ataque a distancia: "Espacio" 

Ataque melee: "E" (ya tiene el pvto parry)

Sprint: "Shift"

Reiniciar: "R"

Salir: "esc"