
Movimiento: WASD & RIGHT, LEFT, UP, DOWN

Ataque a distancia: "Click izquierdo" 

Ataque melee: WASD (selecciona dirección) + "Espacio"

Parry: WASD (selecciona dirección) + "Click derecho)

Sprint: "Shift"

Menu interactivo: "esc"

interactuar: "T" (solo se puede interactuar con la caja por ahora)